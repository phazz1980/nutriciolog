// Firebase client with verbose Auth / Firestore diagnostics.
const firebaseConfig = {
  apiKey: "AIzaSyCnQHJaiKavTsd3meNykdO5IVywiOAAMkI",
  authDomain: "my-nutritionist-67ce8.firebaseapp.com",
  projectId: "my-nutritionist-67ce8",
  storageBucket: "my-nutritionist-67ce8.firebasestorage.app",
  messagingSenderId: "78706346827",
  appId: "1:78706346827:web:066e5c777fd740c194f6ce",
};

const configured = !Object.values(firebaseConfig).some(value => value.startsWith("YOUR_"));
const googleAuthReady = true;
let db, user = null;

const localKey = (collection, id = "") => {
  const owner = user?.uid ? `user:${user.uid}` : "guest";
  return `my-nutritionist:${owner}:${collection}:${id}`;
};

function readLocal(collection, id) {
  const k = localKey(collection, id);
  const raw = localStorage.getItem(k);
  console.log("[LOCAL] read", { key: k, found: Boolean(raw) });
  if (!raw) return null;
  try { return JSON.parse(raw); }
  catch (error) {
    console.error("[LOCAL] invalid JSON", { key: k, error });
    return null;
  }
}

function writeLocal(collection, id, value) {
  const k = localKey(collection, id);
  localStorage.setItem(k, JSON.stringify(value));
  console.log("[LOCAL] saved", { key: k, value });
  return { mode: "local" };
}

async function loadProfile() {
  if (!configured || !user || !db) {
    console.log("[PROFILE] cloud unavailable; reading local profile", {
      configured, hasUser: Boolean(user), hasDb: Boolean(db)
    });
    return readLocal("profile", "main");
  }

  const path = `users/${user.uid}/profile/main`;
  console.log("[FIRESTORE] loading", { uid: user.uid, path });
  try {
    const { doc, getDoc } = window.__firestore;
    const snapshot = await getDoc(doc(db, "users", user.uid, "profile", "main"));
    if (!snapshot.exists()) {
      console.warn("[FIRESTORE] profile document does not exist", { path });
      return null;
    }
    const data = snapshot.data();
    console.log("[FIRESTORE] loaded OK", { path, data });
    return data;
  } catch (error) {
    console.error("[FIRESTORE] load FAILED", {
      path, code: error?.code, message: error?.message, error
    });
    throw error;
  }
}

async function initFirebase() {
  if (!configured) {
    console.warn("[FIREBASE] config is incomplete");
    updateStatus();
    return;
  }
  console.log("[FIREBASE] initializing project", firebaseConfig.projectId);

  const [{ initializeApp }, authSdk, firestoreSdk] = await Promise.all([
    import("https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js"),
    import("https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js"),
    import("https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js"),
  ]);

  const app = initializeApp(firebaseConfig);
  db = firestoreSdk.getFirestore(app);
  window.__firestore = firestoreSdk;

  const auth = authSdk.getAuth(app);
  authSdk.onAuthStateChanged(auth, current => {
    user = current;
    if (user) {
      console.log("[AUTH] signed in", {
        uid: user.uid, email: user.email, displayName: user.displayName
      });
    } else {
      console.log("[AUTH] signed out / guest");
    }
    updateStatus();
    window.dispatchEvent(new Event("nutrition-auth-changed"));
  });

  window.firebaseSignInWithGoogle = async () => {
    console.log("[AUTH] Google sign-in started");
    try {
      const result = await authSdk.signInWithPopup(auth, new authSdk.GoogleAuthProvider());
      console.log("[AUTH] Google sign-in OK", { uid: result.user.uid, email: result.user.email });
      return result;
    } catch (error) {
      console.error("[AUTH] Google sign-in FAILED", { code: error?.code, message: error?.message, error });
      throw error;
    }
  };
  window.firebaseSignOut = () => authSdk.signOut(auth);
  window.getFirebaseIdToken = async () => user ? user.getIdToken() : null;
  window.firebaseSignInWithEmail = (email, password) => authSdk.signInWithEmailAndPassword(auth, email, password);
  window.firebaseRegisterWithEmail = (email, password) => authSdk.createUserWithEmailAndPassword(auth, email, password);
}

function updateStatus() {
  let element = document.getElementById("firebaseStatus");
  if (!element) {
    element = document.createElement("p");
    element.id = "firebaseStatus";
    element.className = "hello";
    const screen = document.getElementById("profile");
    if (screen) screen.prepend(element);
  }
  if (element) element.textContent = configured
    ? (user ? `Синхронизация: ${user.email || "аккаунт подключён"}` : "Войдите, чтобы синхронизировать данные")
    : "Локальный режим: Firebase пока не подключён";
  updateAuthUI();
}

function updateAuthUI() {
  let panel = document.getElementById("authPanel");
  const screen = document.getElementById("profile");
  if (!screen) return;
  if (!panel) { panel = document.createElement("section"); panel.id = "authPanel"; panel.className = "card"; screen.append(panel); }
  if (!configured) { panel.innerHTML = '<b>Гостевой режим</b><p class="hello">Данные остаются на этом устройстве.</p>'; return; }
  if (!googleAuthReady) { panel.innerHTML = '<b>Гостевой режим</b><p class="hello">Google-вход ещё не активирован.</p>'; return; }
  if (user) {
    panel.innerHTML = `<b>${user.email || 'Аккаунт подключён'}</b><p class="hello">Ваши данные синхронизируются с личным аккаунтом.</p><button class="secondary" type="button" id="signOutButton">Выйти</button>`;
    document.getElementById("signOutButton").onclick = () => window.firebaseSignOut();
    return;
  }
  panel.innerHTML = '<b>Синхронизация данных</b><p class="hello">Войдите через Google, чтобы сохранять данные в личном аккаунте.</p><button class="primary" type="button" id="googleSignIn">Войти через Google</button>';
  document.getElementById("googleSignIn").onclick = () =>
    window.firebaseSignInWithGoogle().catch(error => alert(`Не удалось войти через Google: ${error?.code || error?.message || error}`));
}

async function save(collection, id, value) {
  if (!configured || !user || !db) {
    console.warn("[STORE] cloud unavailable; saving locally", {
      collection, id, configured, hasUser: Boolean(user), hasDb: Boolean(db)
    });
    return writeLocal(collection, id, value);
  }

  const path = `users/${user.uid}/${collection}/${id}`;
  console.log("[FIRESTORE] saving", { uid: user.uid, path, value });
  try {
    const { doc, setDoc, serverTimestamp } = window.__firestore;
    await setDoc(
      doc(db, "users", user.uid, collection, id),
      { ...value, updatedAt: serverTimestamp() },
      { merge: true }
    );
    console.log("[FIRESTORE] save OK", { path });
    return { mode: "cloud", path };
  } catch (error) {
    console.error("[FIRESTORE] save FAILED", {
      path, code: error?.code, message: error?.message, error
    });
    const localResult = writeLocal(collection, id, value);
    return {
      ...localResult,
      fallback: true,
      path,
      errorCode: error?.code || "",
      errorMessage: error?.message || String(error)
    };
  }
}

window.nutritionStore = {
  saveProfile: profile => save("profile", "main", profile),
  loadProfile,
  getAccountProfileDefaults: () => ({
    name: user?.displayName || "",
    email: user?.email || "",
    photoUrl: user?.photoURL || ""
  }),
  saveDayPlan: plan => save("dayPlans", plan.date, plan),
  saveWaterLog: log => save("waterLogs", log.date, log),
  saveWeightEntry: entry => save("weightEntries", entry.date, entry),
  saveDiaryEntry: entry => save("foodDiary", `${entry.date}-${crypto.randomUUID()}`, entry),
};

window.dispatchEvent(new Event("nutritionstore-ready"));

window.addProposedMeal = async meal => {
  if (!meal || !meal.title || !Number.isFinite(Number(meal.calories))) {
    throw new Error("Некорректное предложение блюда");
  }
  return window.nutritionStore.saveDiaryEntry({
    date: new Date().toISOString().slice(0, 10),
    mealType: meal.mealType || "Перекус",
    title: meal.title,
    calories: Number(meal.calories),
    source: "ai-confirmed"
  });
};

initFirebase().catch(error => {
  console.error("[FIREBASE] initialization FAILED", {
    code: error?.code, message: error?.message, error
  });
  updateStatus();
});
updateStatus();
